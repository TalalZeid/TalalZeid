var cards = ['10-C.png', '10-D.png', '10-H.png', '10-S.png','2-C.png',  '2-D.png',  '2-H.png',  '2-S.png','3-C.png',  '3-D.png',  '3-H.png',  '3-S.png','4-C.png',  '4-D.png',  '4-H.png',  '4-S.png','5-C.png',  '5-D.png',  '5-H.png',  '5-S.png','6-C.png',  '6-D.png',  '6-H.png',  '6-S.png','7-C.png',  '7-D.png',  '7-H.png',  '7-S.png','8-C.png',  '8-D.png',  '8-H.png',  '8-S.png','9-C.png',  '9-D.png',  '9-H.png',  '9-S.png','A-C.png',  'A-D.png',  'A-H.png',  'A-S.png', 'J-C.png',  'J-D.png','J-H.png',  'J-S.png',  'K-C.png','K-D.png',  'K-H.png',  'K-S.png',  'Q-C.png','Q-D.png',  'Q-H.png',  'Q-S.png'];
var deck =[];

var player = [];
var playerpoints = 0
var assplayercounter=0

var assenemycounter=0 
var enemy = []
var enemypoints = 0

var end = false
var first = false

function start() {
    for(i=0;i<cards.length;i++){
        if(cards[i].length >= 8 || isNaN(parseInt(cards[i][0]))){
            deck.push({
                "value": cards[i][0] == "A" ?  11 : 10,
                "value2":cards[i][0] == "A" ?  1 : null,
                "name":cards[i]
            })
        }else{
            deck.push({
                "value":parseInt(cards[i]),
                "name":cards[i]
            })
        }
    }
    startHand()
}

function startHand() {   
    addPlayercard(true)
    addPlayercard(true)
    addPlayercard(false)
    addPlayercard(false) 
    if(!first && (playerpoints == 21 || enemypoints == 21  )){
        first=true
        checkBtn()
    }  
}

function addPlayercard(isplayer){
    if(isplayer){
        giveRndCard(true)
        handlePlayerCards() 
    }else{
        giveRndCard(false) 
        handleEnemyCards()
    }
}

function giveRndCard(isplayer){
    var rnd = Math.floor(Math.random() * deck.length) + 1;
    var spliceIndex = deck.indexOf(deck[rnd])
    if(isplayer){
        player.push(deck[rnd])
        if(deck[rnd]["value2"] != null){
            assplayercounter++
            playerpoints += deck[rnd]["value"] 
        }else playerpoints += deck[rnd]["value"]
        
        for(i=0;i<player.length;i++){
            if(player[i]["value2"] != null && playerpoints > 21 && assplayercounter >=1){
                playerpoints -=10
                assplayercounter--
            }
        }
        document.getElementById("du").innerHTML = "Du: "+ playerpoints
    }
    else{
        if(enemypoints >= 17) return;
        enemy.push(deck[rnd])
        if(deck[rnd]["value2"] != null){
            assenemycounter++
            enemypoints += deck[rnd]["value"] 
        }else enemypoints += deck[rnd]["value"]
        
        for(i=0;i<enemy.length;i++){
            if(enemy[i]["value2"] != null && enemypoints > 21 && assenemycounter >=1){
                enemypoints -=10
                assenemycounter--
            }
        }
        document.getElementById("er").innerHTML = "Dealer: "+ enemypoints

    }
    deck.splice(spliceIndex , 1)
    if(playerpoints > 21){
        document.getElementById("du").innerHTML = "Du hast VERLOREN (Talal stand NICHT hinter dir): "+ playerpoints
        end=true
    }
}

function handleEnemyCards(){
    var finalHtml = "<img src='./cards/BACK.png'></img>"
    for(i=0;i<enemy.length;i++) finalHtml+=`<img src='./cards/${enemy[i]["name"]}'></img>`
    document.getElementById("dealercards").innerHTML = finalHtml
}

function handlePlayerCards(){
    var finalHtml = ""
    for(i=0;i<player.length;i++) finalHtml+=`<img src='./cards/${player[i]["name"]}'></img>`
    
    document.getElementById("mycards").innerHTML = finalHtml
}

function checkBtn(){
    if(enemypoints > 21 || (playerpoints > enemypoints && playerpoints <= 21) ||  (enemypoints!=playerpoints && (playerpoints > enemypoints) && playerpoints <= 21)){
        document.getElementById("du").innerHTML = "Du hast gewonnen (Talal stand hinter dir): "+ playerpoints
        document.getElementById("lottie").style.display = "fix"

    }
    else document.getElementById("du").innerHTML = "Du hast VERLOREN (Talal stand NICHT hinter dir): "+ playerpoints
    end=true
}

start() 